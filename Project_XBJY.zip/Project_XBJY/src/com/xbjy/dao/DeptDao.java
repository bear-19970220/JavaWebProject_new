package com.xbjy.dao;

import com.xbjy.domain.Dept;

import java.util.List;

public interface DeptDao {

    List<Dept> findAllDept();

}
