package com.xbjy.service;

import com.xbjy.domain.Menu;

import java.util.List;

/**
 * @author 杨智球
 * @company 东方标准
 * @date 2019/12/2 12:22
 */
public interface MenuService {

    public abstract List<Menu> listMenu();

}
