package com.xbjy.service;

import com.xbjy.domain.Dept;

import java.util.List;

public interface DeptService {

    List<Dept> listDept();


}
